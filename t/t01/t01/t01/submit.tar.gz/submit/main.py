from scoretable import *

